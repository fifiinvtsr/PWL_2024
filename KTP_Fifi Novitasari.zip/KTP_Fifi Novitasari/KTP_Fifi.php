<?php
$nik = "123456789101112134";
$nama = "FIFI NOVITASARI";
$tempat_lahir = "PASURUAN";
$tanggal_lahir = "13-12-2003";
$jenis_kelamin = "PEREMPUAN";
$gol_darah = "-";
$alamat = "JL. DR CIPTO Gg VIII";
$rt_rw = "002/010";
$kel_desa = "BEDALI";
$kecamatan = "LAWANG";
$agama = "ISLAM";
$status_perkawinan = "BELUM KAWIN";
$pekerjaan = "PELAJAR/MAHASISWA";
$kewarganegaraan = "WNI";
$berlaku_hingga = "SEUMUR HIDUP";